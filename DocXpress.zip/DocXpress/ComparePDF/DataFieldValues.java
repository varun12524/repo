package ComparePDF;

import java.util.ArrayList;
import java.util.List;

public class DataFieldValues {
	//Excel Data
	static String Execute;
	static String TestCase;
	static String TestCaseID;
	static String POAddressexcel;
	static String PONumberexcel;
	static String PODateexcel;
	static String ToAddresseexcel;
	static String Currencyeexcel;
	static String RequestedByeexcel;
	static String RequestedDateeexcel;
	static String ApprovedByeexcel;
	static String ApprovedDateeexcel;
	static String Uniquevalue;
		//Table Data
	static ArrayList<String> ItemNoeexcel;
	static ArrayList<String> Quantityeexcel;
	static ArrayList<String> Descriptioneexcel;
	static ArrayList<String> UnitPriceeexcel;
	static ArrayList<String> Amounteexcel;
		
	//Setters and Getters for Excel Data
	public static String getExecute() {
		return Execute;
	}
	public static void setExecute(String execute) {
		Execute = execute;
	}
	public static String getTestCase() {
		return TestCase;
	}
	public static void setTestCase(String testCase) {
		TestCase = testCase;
	}
	public static String getTestCaseID() {
		return TestCaseID;
	}
	public static void setTestCaseID(String testCaseID) {
		TestCaseID = testCaseID;
	}
	public static String getPOAddressexcel() {
		return POAddressexcel;
	}
	public static void setPOAddressexcel(String pOAddressexcel) {
		POAddressexcel = pOAddressexcel;
	}
	public static String getPONumberexcel() {
		return PONumberexcel;
	}
	public static void setPONumberexcel(String pONumberexcel) {
		PONumberexcel = pONumberexcel;
	}
	public static String getPODateexcel() {
		return PODateexcel;
	}
	public static void setPODateexcel(String pODateexcel) {
		PODateexcel = pODateexcel;
	}
	public static String getToAddresseexcel() {
		return ToAddresseexcel;
	}
	public static void setToAddresseexcel(String toAddresseexcel) {
		ToAddresseexcel = toAddresseexcel;
	}
	public static String getCurrencyeexcel() {
		return Currencyeexcel;
	}
	public static void setCurrencyeexcel(String currencyeexcel) {
		Currencyeexcel = currencyeexcel;
	}
	public static String getRequestedByeexcel() {
		return RequestedByeexcel;
	}
	public static void setRequestedByeexcel(String requestedByeexcel) {
		RequestedByeexcel = requestedByeexcel;
	}
	public static String getRequestedDateeexcel() {
		return RequestedDateeexcel;
	}
	public static void setRequestedDateeexcel(String requestedDateeexcel) {
		RequestedDateeexcel = requestedDateeexcel;
	}
	public static String getApprovedByeexcel() {
		return ApprovedByeexcel;
	}
	public static void setApprovedByeexcel(String approvedByeexcel) {
		ApprovedByeexcel = approvedByeexcel;
	}
	public static String getApprovedDateeexcel() {
		return ApprovedDateeexcel;
	}
	public static void setApprovedDateeexcel(String approvedDateeexcel) {
		ApprovedDateeexcel = approvedDateeexcel;
	}
	
	public static String getUniquevalue() {
		return Uniquevalue;
	}
	public static void setUniquevalue(String uniquevalue) {
		Uniquevalue = uniquevalue;
	}
	
	//Table data
	public static ArrayList<String> getItemNoeexcel() {
		return ItemNoeexcel;
	}
	public static void setItemNoeexcel(ArrayList<String> itemNoeexcel) {
		ItemNoeexcel = itemNoeexcel;
	}
	public static ArrayList<String> getQuantityeexcel() {
		return Quantityeexcel;
	}
	public static void setQuantityeexcel(ArrayList<String> quantityeexcel) {
		Quantityeexcel = quantityeexcel;
	}
	public static ArrayList<String> getDescriptioneexcel() {
		return Descriptioneexcel;
	}
	public static void setDescriptioneexcel(ArrayList<String> descriptioneexcel) {
		Descriptioneexcel = descriptioneexcel;
	}
	public static ArrayList<String> getUnitPriceeexcel() {
		return UnitPriceeexcel;
	}
	public static void setUnitPriceeexcel(ArrayList<String> unitPriceeexcel) {
		UnitPriceeexcel = unitPriceeexcel;
	}
	public static ArrayList<String> getAmounteexcel() {
		return Amounteexcel;
	}
	public static void setAmounteexcel(ArrayList<String> amounteexcel) {
		Amounteexcel = amounteexcel;
	}
	//PDF Data
		static String POAddresspdf;
		static String PONumberpdf;
		static String PODatepdf;
		static String ToAddresspdf;
		static String Currencypdf;
		static String RequestedBypdf;
		static String RequestedDatepdf;
		static String ApprovedBypdf;
		static String ApprovedDatepdf;
			//Table data
		static ArrayList<String> ItemNopdf;
		static ArrayList<String> Quantitypdf;
		static ArrayList<String> Descriptionpdf;
		static ArrayList<String> UnitPricepdf;
		static ArrayList<String> Amountpdf;

		public static String getPOAddresspdf() {
			return POAddresspdf;
		}
		public static void setPOAddresspdf(String pOAddresspdf) {
			POAddresspdf = pOAddresspdf;
		}
		public static String getPONumberpdf() {
			return PONumberpdf;
		}
		public static void setPONumberpdf(String pONumberpdf) {
			PONumberpdf = pONumberpdf;
		}
		public static String getPODatepdf() {
			return PODatepdf;
		}
		public static void setPODatepdf(String pODatepdf) {
			PODatepdf = pODatepdf;
		}
		public static String getToAddresspdf() {
			return ToAddresspdf;
		}
		public static void setToAddresspdf(String toAddresspdf) {
			ToAddresspdf = toAddresspdf;
		}
		public static String getCurrencypdf() {
			return Currencypdf;
		}
		public static void setCurrencypdf(String currencypdf) {
			Currencypdf = currencypdf;
		}
		public static String getRequestedBypdf() {
			return RequestedBypdf;
		}
		public static void setRequestedBypdf(String requestedBypdf) {
			RequestedBypdf = requestedBypdf;
		}
		public static String getRequestedDatepdf() {
			return RequestedDatepdf;
		}
		public static void setRequestedDatepdf(String requestedDatepdf) {
			RequestedDatepdf = requestedDatepdf;
		}
		public static String getApprovedBypdf() {
			return ApprovedBypdf;
		}
		public static void setApprovedBypdf(String approvedBypdf) {
			ApprovedBypdf = approvedBypdf;
		}
		public static String getApprovedDatepdf() {
			return ApprovedDatepdf;
		}
		public static void setApprovedDatepdf(String approvedDatepdf) {
			ApprovedDatepdf = approvedDatepdf;
		}
		//Table Data
		public static ArrayList<String> getItemNopdf() {
			return ItemNopdf;
		}
		public static void setItemNopdf(ArrayList<String> itemNopdf) {
			ItemNopdf = itemNopdf;
		}
		public static ArrayList<String> getQuantitypdf() {
			return Quantitypdf;
		}
		public static void setQuantitypdf(ArrayList<String> quantitypdf) {
			Quantitypdf = quantitypdf;
		}
		public static ArrayList<String> getDescriptionpdf() {
			return Descriptionpdf;
		}
		public static void setDescriptionpdf(ArrayList<String> descriptionpdf) {
			Descriptionpdf = descriptionpdf;
		}
		public static ArrayList<String> getUnitPricepdf() {
			return UnitPricepdf;
		}
		public static void setUnitPricepdf(ArrayList<String> unitPricepdf) {
			UnitPricepdf = unitPricepdf;
		}
		public static ArrayList<String> getAmountpdf() {
			return Amountpdf;
		}
		public static void setAmountpdf(ArrayList<String> amountpdf) {
			Amountpdf = amountpdf;
		}
	
}
