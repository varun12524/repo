package ComparePDF;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.awt.Rectangle;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripperByArea;

public class ExtractTextfromPDF {
	static String totaltextofPDF;
	public static String PONumber,PODate,POAddress,ToAddress,Currency,RequestedBy,Requesteddate,ApprovedBy,ApprovedDate;
	public static int index1,index2,index3,index4;
	static DataFieldValues dataSheet = null;
	static List<DataFieldValues> dataSheetList = new ArrayList<DataFieldValues>();
	public List<DataFieldValues> extractText(String pdffilepath) throws Exception{
		//String[] PDFValues = new String[9];
		PDFManager pdfManager1 = new PDFManager();
		pdfManager1.setFilePath(pdffilepath);
		totaltextofPDF = pdfManager1.ToText();
		dataSheet.setPONumberpdf(getPONumber());
		dataSheet.setPODatepdf(getPODate());
		dataSheet.setPOAddresspdf(getPOAddress());
		dataSheet.setToAddresspdf(getToAddress());
		dataSheet.setCurrencypdf(getCurrency());
	    dataSheet.setRequestedBypdf(getRequestedBy());
	    dataSheet.setRequestedDatepdf(getRequesteddate());
	    dataSheet.setApprovedBypdf(getApprovedBy());
	    dataSheet.setApprovedDatepdf(getApproveddate());
	    getTableContent(pdffilepath);
	    dataSheetList.add(dataSheet);
	    return dataSheetList;
	    
	} 
	static String po,dt;
	public static String getPONumber() {  
		index1=totaltextofPDF.indexOf("PO No. ",0);	// index of PO Number 
		PONumber = totaltextofPDF.substring(index1+7).substring(0, 10);		//String starting from index1 till end
		//System.out.println("PO Number:\n"+PONumber);
		return PONumber;
	}
	public static String getPODate() {  
		int index2=totaltextofPDF.indexOf("Date ",index1);		//Index of Date
		dt = totaltextofPDF.substring(index2+5);
		PODate = dt.substring(0, 11);
		//System.out.println("PO date:\n"+PODate);
		System.out.println(totaltextofPDF);
		return PODate;
	}
	public static String getPOAddress() {
		String temp1 = totaltextofPDF.substring(0, index1-1);
		String temp2 = totaltextofPDF.substring(index1+17);
		int tempindex = temp2.indexOf("Date ", 0);
		String temp3 = temp2.substring(0,tempindex-1);
		String temp4 = temp2.substring(tempindex+16);
		String temp5 = temp1+temp3+temp4;
		index3=temp5.indexOf("PURCHASE ORDER",0);
		POAddress= temp5.substring(0,index3-2).replace("\r", "");
		System.out.println("PO Address:\n"+POAddress);
		return POAddress;
	}
	public static String getToAddress(){
		int tempindex1 = totaltextofPDF.indexOf("To: ", index3);
		String temp1 = totaltextofPDF.substring(tempindex1+4);
		int tempindex2 = temp1.indexOf("Please supply the following:",0);
		ToAddress = temp1.substring(0,tempindex2-2).replace("\r", "");
		//System.out.println("To Address:\n"+ToAddress);
		return ToAddress;
	}
	public static String getCurrency(){
		int tempindex3 = totaltextofPDF.indexOf("Item No. Quantity Description Unit Price Amount", index3)+49;
		Currency = totaltextofPDF.substring(tempindex3,tempindex3+3).replace("\r\n", "");
		//System.out.println("Currency: "+Currency);
		return Currency;
	}
	public static String getRequestedBy(){
		int tempindex1 = totaltextofPDF.indexOf("Requested By : ", 0);
		String temp1 = totaltextofPDF.substring(tempindex1+15);
		int tempindex2 = temp1.indexOf("Approved By : ",0);
		RequestedBy = temp1.substring(0,tempindex2-1);
		//System.out.println("Requested By: "+RequestedBy);
		return RequestedBy;
	}
	public static String getRequesteddate(){
		int tempindex1 = totaltextofPDF.indexOf("Requested By : ", 0);
		String temp1 = totaltextofPDF.substring(tempindex1+15);
		int tempindex3 = temp1.indexOf("Date : " ,0);
		Requesteddate = temp1.substring(tempindex3+7,tempindex3+18);
		//System.out.println("Requested Date: "+Requesteddate);
		return Requesteddate;
	}
	public static String getApprovedBy(){
		int tempindex1 = totaltextofPDF.indexOf("Approved By : ", 0);
		String temp1 = totaltextofPDF.substring(tempindex1+14);
		int tempindex2 = temp1.indexOf("Date : ",0);
		ApprovedBy = temp1.substring(0,tempindex2-2).replace("\r\n", "");
		//System.out.println("Approved By: "+ApprovedBy);
		return ApprovedBy;
	}
	public static String getApproveddate(){
		int tempindex1 = totaltextofPDF.indexOf("Approved By : ", 0);
		String temp1 = totaltextofPDF.substring(tempindex1+14);
		int tempindex3 = temp1.indexOf("Date : " ,0);
		int tempindex4 = temp1.indexOf("Date : " ,tempindex3+4);
		ApprovedDate = temp1.substring(tempindex4+7,tempindex4+18).replace("\r\n", "");
		//System.out.println("Approved Date: "+ApprovedDate);
		return ApprovedDate;
	}
	public static List<DataFieldValues> getTableContent( String loaddocument ) throws Exception
	{   
		
		PDDocument document = null;
		int y=0;
		try
		{
			ArrayList<String> itemno = new ArrayList<String>();
			ArrayList<String> quantity = new ArrayList<String>();
			ArrayList<String> description = new ArrayList<String>();
			ArrayList<String> unitprice = new ArrayList<String>();
			ArrayList<String> amount = new ArrayList<String>();
			document = PDDocument.load( loaddocument );
			int j=0;
			PDFTextStripperByArea stripper = new PDFTextStripperByArea();
			stripper.setSortByPosition( true );
			List<PDPage> allPages = document.getDocumentCatalog().getAllPages();
			System.out.println("Total No. of pages: "+allPages.size());
			outerloop:for(int page=0;page<allPages.size();page++){
			PDPage firstPage = (PDPage)allPages.get(page);
			y = PrintTextLocations.getYvalue(loaddocument,page,"Item");
			System.out.println("Coordinates of Item No "+y);
			for(int i=1;i<=68;i++){
				//For end of table
				Rectangle rect = new Rectangle(440 , y+(i*6), 60, 6);
				stripper.addRegion( "class1", rect );
				stripper.extractRegions( firstPage );
				if(stripper.getTextForRegion( "class1" ).contains("% GST")){
					break outerloop;
				}
				//For checking Item No
				Rectangle rect1 = new Rectangle(80 , y+(i*6), 60, 6);
				stripper.addRegion( "class1", rect1 );
				stripper.extractRegions( firstPage );
				String tem1 = stripper.getTextForRegion( "class1" );
				if(!tem1.replace("\r\n", "").isEmpty()){
					itemno.add(tem1.replace("\r\n", ""));
					//For checking Quantity
					Rectangle rect2 = new Rectangle(120 , y+(i*6), 60, 6);
					stripper.addRegion( "class1", rect2 );
					stripper.extractRegions( firstPage );
					String tem2 = stripper.getTextForRegion( "class1" );
					if(!tem2.replace("\r\n", "").isEmpty()){
						quantity.add(tem2.replace("\r\n", ""));
					}
					//For Description
					Rectangle rect3 = new Rectangle(180 , y+(i*6), 210, 6);
					stripper.addRegion( "class1", rect3 );
					stripper.extractRegions( firstPage );
					String tem3 = stripper.getTextForRegion( "class1" );
					if(!tem3.replace("\r\n", "").isEmpty()){
						description.add(tem3.replace("\r\n", ""));
					}
					//For Unit Price
					Rectangle rect5 = new Rectangle(440 , y+(i*6), 60, 6);
					stripper.addRegion( "class1", rect5 );
					stripper.extractRegions( firstPage );
					String tem5 = stripper.getTextForRegion( "class1" );
					if(!tem5.replace("\r\n", "").isEmpty()){
						unitprice.add(tem5.replace("\r\n", ""));
					}
					//For Amount
					Rectangle rect6 = new Rectangle(500 , y+(i*6), 60, 6);
					stripper.addRegion( "class1", rect6 );
					stripper.extractRegions( firstPage );
					String tem6 = stripper.getTextForRegion( "class1" );
					if(!tem6.replace("\r\n", "").isEmpty()){
						amount.add(tem6.replace("\r\n", ""));
					}
					j++;	//For All
				}
				//===================For Description====================================//
				else{
					Rectangle rect4 = new Rectangle(200 , y+(i*6), 210, 6);
					stripper.addRegion( "class1", rect4 );
					stripper.extractRegions( firstPage );
					String tem4 = stripper.getTextForRegion( "class1" );
					if(!tem4.replace("\r\n", "").isEmpty()){
						description.set(j-1 , description.get(j-1)+tem4.replace("\r\n", ""));
					}
				}
				//===================For Description====================================//
			}
			}
			
			System.out.println("itemno:\n"+itemno);
			System.out.println("Quantity:\n"+quantity);
			System.out.println("Description:\n"+description);
			System.out.println("Unit Price:\n"+unitprice);
			System.out.println("Amount:\n"+amount);	
			
			dataSheet.setItemNopdf(itemno);
			dataSheet.setQuantitypdf(quantity);
			dataSheet.setDescriptionpdf(description);
			dataSheet.setUnitPricepdf(unitprice);
			dataSheet.setAmountpdf(amount);
		}
		finally
		{
			if( document != null )
			{
				document.close();
			}
		}
		return dataSheetList;
	}
}
