package ComparePDF;

import java.io.FileInputStream;

import ComparePDF.DataFieldValues;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream.GetField;
import java.lang.reflect.Array;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import javax.xml.crypto.Data;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;

public class ComparePDFwithExcel {
	private static String[] html1=null,html2=null;
	static StringDifference obj = null;
	private static String[] itemnohtml1=null,itemnohtml2=null,quantityhtml1=null,quantityhtml2=null,descriptionhtml1=null,descriptionhtml2=null,unitpricehtml1=null,unitpricehtml2=null,amounthtml1=null,amounthtml2=null;
	public static String[] comparePDFwithExcel(String pdffilepath,String[] PDFValues, String[] excelvalues) throws Exception
	{
		ExtractTextfromPDF obj2 = new ExtractTextfromPDF();
		//String[] PDFValues = obj2.extractText(pdffilepath);
		String[] match = new String[PDFValues.length];
		html1 = new String[PDFValues.length];
		html2 = new String[PDFValues.length];
		for(int k=0; k<PDFValues.length;k++){
			obj = new StringDifference();
			 String[] result = obj.compareStrings(PDFValues[k], excelvalues[k]);
			 match[k] = result[0];
			 html1[k] = result[1];
			 html2[k] = result[2];
 		}
		/*if(PDFValues[0].replace("\r", "").equalsIgnoreCase(excelvalues[0].replace("\r", ""))){
			System.out.println("PO Address Match Found");
			result[0] = "Matched";
		}
		else{
			System.out.println("PO Address Match not Found");
			System.out.println("Value From PDF:\n"+PDFValues[0]);
			System.out.println("Value From DataSheet:\n"+excelvalues[0]);
			result[0] = "UnMatched";
		}
		if(PDFValues[1].equalsIgnoreCase(excelvalues[1])){
			System.out.println("PO Number Match Found");
			result[1] = "Matched";
		}
		else{
			System.out.println("PO Number Match not Found");
			System.out.println("Value From PDF:\n"+PDFValues[1]);
			System.out.println("Value From DataSheet:\n"+excelvalues[1]);
			result[1] = "UnMatched";
		}
		if(PDFValues[2].equalsIgnoreCase(excelvalues[2])){
			System.out.println("PO Date Match Found");
			result[2] = "Matched";
		}
		else{
			System.out.println("PO Date Match not Found");
			System.out.println("Value From PDF:\n"+PDFValues[2]);
			System.out.println("Value From DataSheet:\n"+excelvalues[2]);
			result[2] = "UnMatched";
		}
		if(PDFValues[3].replace("\r", "").equalsIgnoreCase(excelvalues[3].replace("\r", ""))){
			System.out.println("To Address Match Found");
			result[3] = "Matched";
		}
		else{
			System.out.println("To Address Match not Found");
			System.out.println("Value From PDF:\n"+PDFValues[3]);
			System.out.println("Value From DataSheet:\n"+excelvalues[3]);
			result[3] = "UnMatched";
		}
		if(PDFValues[4].equalsIgnoreCase(excelvalues[4])){
			System.out.println("Currency Match Found");
			result[4] = "Matched";
		}
		else{
			System.out.println("Currency Match not Found");
			System.out.println("Value From PDF:\n"+PDFValues[4]);
			System.out.println("Value From DataSheet:\n"+excelvalues[4]);
			result[4] = "UnMatched";
		}
		if(PDFValues[5].equalsIgnoreCase(excelvalues[5])){
			System.out.println("Requested By Match Found");
			result[5] = "Matched";
		}
		else{
			System.out.println("Requested By Match not Found");
			System.out.println("Value From PDF:\n"+PDFValues[5]);
			System.out.println("Value From DataSheet:\n"+excelvalues[5]);
			result[5] = "UnMatched";
		}
		if(PDFValues[6].equalsIgnoreCase(excelvalues[6])){
			System.out.println("Requested Date Match Found");
			result[6] = "Matched";
		}
		else{
			System.out.println("Requested Date Match not Found");
			System.out.println("Value From PDF:\n"+PDFValues[6]);
			System.out.println("Value From DataSheet:\n"+excelvalues[6]);
			result[6] = "UnMatched";
		}
		if(PDFValues[7].equalsIgnoreCase(excelvalues[7])){
			System.out.println("Approved By Match Found");
			result[7] = "Matched";
		}
		else{
			System.out.println("Approved By Match not Found");
			System.out.println("Value From PDF:\n"+PDFValues[7]);
			System.out.println("Value From DataSheet:\n"+excelvalues[7]);
			result[7] = "UnMatched";
		}
		if(PDFValues[8].equalsIgnoreCase(excelvalues[8])){
			System.out.println("Approved Date Match Found");
			result[8] = "Matched";
		}
		else{
			System.out.println("Approved Date Match not Found");
			System.out.println("Value From PDF:\n"+PDFValues[8]);
			System.out.println("Value From DataSheet:\n"+excelvalues[8]);
			result[8] = "UnMatched";
		}*/
		return match;
	}
	public static String[][] compareTableValues() throws IOException {
		//From Excel
		ArrayList<String> itemnoexcel = new ArrayList<String>();
		ArrayList<String> quantityexcel = new ArrayList<String>();
		ArrayList<String> descriptionexcel = new ArrayList<String>();
		ArrayList<String> unitpriceexcel = new ArrayList<String>();
		ArrayList<String> amountexcel = new ArrayList<String>();
		itemnoexcel = DataFieldValues.getItemNoeexcel();
		quantityexcel =DataFieldValues.getQuantityeexcel();
		descriptionexcel = DataFieldValues.getDescriptioneexcel();
		unitpriceexcel = DataFieldValues.getUnitPriceeexcel();
		amountexcel = DataFieldValues.getAmounteexcel(); 
		//From PDF
		ArrayList<String> itemnopdf = new ArrayList<String>();
		ArrayList<String> quantitypdf = new ArrayList<String>();
		ArrayList<String> descriptionpdf = new ArrayList<String>();
		ArrayList<String> unitpricepdf = new ArrayList<String>();
		ArrayList<String> amountpdf = new ArrayList<String>();
		itemnopdf = DataFieldValues.getItemNopdf();
		quantitypdf =DataFieldValues.getQuantitypdf();
		descriptionpdf = DataFieldValues.getDescriptionpdf();
		unitpricepdf = DataFieldValues.getUnitPricepdf();
		amountpdf = DataFieldValues.getAmountpdf();
		int len = itemnopdf.size();
		itemnohtml1 = new String[len];
		itemnohtml2 = new String[len];
		quantityhtml1 = new String[len];
		quantityhtml2 = new String[len];
		descriptionhtml1 = new String[len];
		descriptionhtml2 = new String[len];
		unitpricehtml1 = new String[len];
		unitpricehtml2 = new String[len];
		amounthtml1 = new String[len];
		amounthtml2 = new String[len];
		
		for(int n=0; n<len;n++){
			obj = new StringDifference();
			String[] result1 = obj.compareStrings(itemnopdf.get(n),itemnoexcel.get(n));
			itemnohtml1[n] = result1[1];
			itemnohtml2[n] = result1[2];
			String[] result2 = obj.compareStrings(quantitypdf.get(n),quantityexcel.get(n));
			quantityhtml1[n] = result2[1];
			quantityhtml2[n] = result2[2];
			String[] result3 = obj.compareStrings(descriptionpdf.get(n),descriptionexcel.get(n));
			descriptionhtml1[n] = result3[1];
			descriptionhtml2[n] = result3[2];
			String[] result4 = obj.compareStrings(unitpricepdf.get(n),unitpriceexcel.get(n));
			unitpricehtml1[n] = result4[1];
			unitpricehtml2[n] = result4[2];
			String[] result5 = obj.compareStrings(amountpdf.get(n),amountexcel.get(n));
			amounthtml1[n] = result5[1];
			amounthtml2[n] = result5[2];
 		}
		String[][] htmls = new String[len][10];
		for(int r=0;r<len;r++){
			htmls[r][0] = itemnohtml1[r];
			htmls[r][1] = quantityhtml1[r];
			htmls[r][2] = descriptionhtml1[r];
			htmls[r][3] = unitpricehtml1[r];
			htmls[r][4] = amounthtml1[r];
			htmls[r][5] = itemnohtml2[r];
			htmls[r][6] = quantityhtml1[r];
			htmls[r][7] = descriptionhtml2[r];
			htmls[r][8] = unitpricehtml2[r];
			htmls[r][9] = amounthtml2[r];
		}				
		return htmls;
		
	}
	
	
	
	
	
	public static void main(String args[]) throws Exception{
		
		String excelfilepath = "D:\\Varun\\ACE\\PDFValidationDocuments\\TestData\\TestDataForDynamicPDF.xls";
		
		//=================================Read Data From Excel=========================================================//
		ReadDatafromExcel obj5 = new ReadDatafromExcel();
		String[][] executables = obj5.runManager(excelfilepath);
		for(int x=0;x<executables.length;x++){
			DataFieldValues dataSheet = null;
			ReadDatafromExcel obj1 = new ReadDatafromExcel();
			dataSheet.setTestCaseID(executables[x][0]);
			String pdffilepath = executables[x][2];
			System.out.println("PDF File: "+pdffilepath);
			obj1.readDatafromDataSheet(excelfilepath,"Data",dataSheet.getTestCaseID());
			String POAddressexcel = DataFieldValues.getPOAddressexcel();
			String PONumberexcel= DataFieldValues.getPONumberexcel();
			String PODateexcel = DataFieldValues.getPODateexcel();
			String ToAddressexcel = DataFieldValues.getToAddresseexcel();
			String Currencyexcel = DataFieldValues.getCurrencyeexcel();
			String RequestedByexcel = DataFieldValues.getRequestedByeexcel();
			String RequestedDateexcel = DataFieldValues.getRequestedDateeexcel();
			String ApprovedByexcel = DataFieldValues.getApprovedByeexcel();
			String ApprovedDateexcel = DataFieldValues.getApprovedDateeexcel();
			String[] excelvalues = { POAddressexcel, PONumberexcel, PODateexcel, ToAddressexcel, Currencyexcel, RequestedByexcel, RequestedDateexcel, ApprovedByexcel, ApprovedDateexcel};
			obj1.readTabledata(excelfilepath, "Table Data", "01");
			//==================================Extract Data from PDF================================================//
			ExtractTextfromPDF obj2 = new ExtractTextfromPDF();
			obj2.extractText(pdffilepath);
			String POAddresspdf = DataFieldValues.getPOAddresspdf();
			String PONumberpdf  = DataFieldValues.getPONumberpdf();
			String PODatepdf  = DataFieldValues.getPODatepdf();
			String ToAddresspdf  = DataFieldValues.getToAddresspdf();
			String Currencypdf  = DataFieldValues.getCurrencypdf();
			String RequestedBypdf  = DataFieldValues.getRequestedBypdf();
			String RequestedDatepdf  = DataFieldValues.getRequestedDatepdf();
			String ApprovedBypdf  = DataFieldValues.getApprovedBypdf();
			String ApprovedDatepdf  = DataFieldValues.getApprovedDatepdf();
			String[] PDFValues = {POAddresspdf, PONumberpdf, PODatepdf, ToAddresspdf, Currencypdf, RequestedBypdf, RequestedDatepdf, ApprovedBypdf, ApprovedDatepdf};
			String[] match = comparePDFwithExcel(pdffilepath,PDFValues,excelvalues);
			String[][] tableresults = compareTableValues();
			Result.writetohtml(pdffilepath,"Result",match,html1,html2,tableresults);
		}
		/*============================Copy File================================================//
		File source = new File(pdffilepath);
		File dest = new File("D:\\Varun\\ACE\\PDFValidationDocuments\\FinalResult\\System Generated Purchase Order for POHK100194.pdf");
		Result.copyFile(source, dest);
		 */
	}
	
}
	
	