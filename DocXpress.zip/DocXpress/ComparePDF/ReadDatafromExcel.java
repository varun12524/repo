package ComparePDF;

import java.awt.print.Book;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;


public class ReadDatafromExcel {
	
	
	
	static DataFieldValues dataSheet = null;
	static List<DataFieldValues> dataSheetList = new ArrayList<DataFieldValues>();
	static Row row = null;
	static HSSFCell cell =null;
	
	
	public static List<DataFieldValues> readDatafromDataSheet(String filePath, String sheetName,String TestCase) throws Exception{
		int rows_total1,rownum=0;
		FileInputStream inputStream = new FileInputStream(filePath);
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheet(sheetName);
		rows_total1 = sheet.getLastRowNum();
		System.out.println("Total No. of rows:"+rows_total1);
		for(int t=0;t<=rows_total1;t++){
			row = sheet.getRow(t);
			dataSheet = new DataFieldValues();
			cell = (HSSFCell) row.getCell(0);
			cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			if(cell.getStringCellValue().equalsIgnoreCase(TestCase)){
				rownum=t;
			}
		}
		if(rownum<=rows_total1){
			row = sheet.getRow(rownum);
			dataSheet = new DataFieldValues();
			cell = (HSSFCell) row.getCell(0);
			cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			dataSheet.setTestCaseID(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(1);
			dataSheet.setPOAddressexcel(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(2);
			dataSheet.setPONumberexcel(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(3);
			dataSheet.setPODateexcel(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(4);
			dataSheet.setToAddresseexcel(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(5);
			dataSheet.setCurrencyeexcel(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(6);
			dataSheet.setRequestedByeexcel(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(7);
			dataSheet.setRequestedDateeexcel(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(8);
			dataSheet.setApprovedByeexcel(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(9);
			dataSheet.setApprovedDateeexcel(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(10);
			dataSheet.setUniquevalue(cell.getStringCellValue());
			dataSheetList.add(dataSheet);
			workbook.close();
		}
		else{
			System.out.println("Row Number "+rownum+" does not Exist");
		}
		return dataSheetList;
	}
	
	public List<DataFieldValues> readTabledata(String filePath, String sheetName,String uniquevalue) throws IOException{
		int rows_total2;
		FileInputStream inputStream = new FileInputStream(filePath);
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheet(sheetName);
		rows_total2 = sheet.getLastRowNum();
		System.out.println("Total No. of rows:"+rows_total2);
		ArrayList<String> itemno = new ArrayList<String>();
		ArrayList<String> quantity = new ArrayList<String>();
		ArrayList<String> description = new ArrayList<String>();
		ArrayList<String> unitprice = new ArrayList<String>();
		ArrayList<String> amount = new ArrayList<String>();
		int i = 1;
		while(i<=rows_total2){
			row = sheet.getRow(i);
			dataSheet = new DataFieldValues();
			cell = (HSSFCell) row.getCell(0);
			cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			if(cell.getStringCellValue().equalsIgnoreCase(DataFieldValues.getUniquevalue())){
				cell = (HSSFCell) row.getCell(1);
				itemno.add(cell.getStringCellValue());
				cell = (HSSFCell) row.getCell(2);
				quantity.add(cell.getStringCellValue());
				cell = (HSSFCell) row.getCell(3);
				description.add(cell.getStringCellValue());
				cell = (HSSFCell) row.getCell(4);
				unitprice.add(cell.getStringCellValue());
				cell = (HSSFCell) row.getCell(5);
				amount.add(cell.getStringCellValue());
			}
			i++;
		}
		dataSheet.setItemNoeexcel(itemno);
		dataSheet.setQuantityeexcel(quantity);
		dataSheet.setDescriptioneexcel(description);
		dataSheet.setUnitPriceeexcel(unitprice);
		dataSheet.setAmounteexcel(amount);
		dataSheetList.add(dataSheet);
		return dataSheetList;
	}
	
	public String[][] runManager(String excelfilePath) throws IOException{
		int rows_total3,exetc=0;
		//ArrayList<String> testCases = new ArrayList<String>();
		//ArrayList<String> execute = new ArrayList<String>();
		FileInputStream inputStream = new FileInputStream(excelfilePath);
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheet("Run Configuration");
		rows_total3 = sheet.getLastRowNum();
		System.out.println("Total No. of rows:"+rows_total3);
		String[][] testCases = new String[rows_total3+1][3];
		for(int t=0;t<=rows_total3;t++){
			row = sheet.getRow(t);
			dataSheet = new DataFieldValues();
			cell = (HSSFCell) row.getCell(0);
			cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			testCases[t][0] = cell.getStringCellValue();
			System.out.println(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(1);
			testCases[t][1] = cell.getStringCellValue();
			System.out.println(cell.getStringCellValue());
			cell = (HSSFCell) row.getCell(2);
			testCases[t][2] = cell.getStringCellValue();
			System.out.println(cell.getStringCellValue());
			if(testCases[t][1].equalsIgnoreCase("Yes")){
				exetc++;
			}
		}
		workbook.close();
		System.out.println("Total No. of Executable test Cases"+exetc);
		String[][] executables = new String[exetc][3];
		for(int e=1,i=0;e<=rows_total3;e++){
			if(testCases[e][1].equalsIgnoreCase("Yes")){
				executables[i][0] = testCases[e][0];
				executables[i][1] = testCases[e][1];
				executables[i][2] = testCases[e][2];
				i++;
			}
		}
		return executables;
		
		
	}
}
