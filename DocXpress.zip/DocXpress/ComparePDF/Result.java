package ComparePDF;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ibm.icu.text.DateFormat;

public class Result {
	
	static void copyFile(File sourceFile, File destFile)
			throws IOException {
		if (!sourceFile.exists()) {
			return;
		}
		if (!destFile.exists()) {
			destFile.createNewFile();
		}
		FileChannel source = null;
		FileChannel destination = null;
		source = new FileInputStream(sourceFile).getChannel();
		destination = new FileOutputStream(destFile).getChannel();
		if (destination != null && source != null) {
			destination.transferFrom(source, 0, source.size());
		}
		if (source != null) {
			source.close();
		}
		if (destination != null) {
			destination.close();
		}
	}
	
	public static void writetohtml(String pdffilepath,String sheetName,String[] result,String[] html1,String[] html2,String[][] tableresults) throws IOException{
		/*FileInputStream inputStream = new FileInputStream(excelfilepath);
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheet(sheetName);       
		int rows_total = sheet.getLastRowNum();
		Row row = sheet.createRow(++rows_total);
		row.createCell(0).setCellValue(DataFieldValues.getTestCaseID());
		
		for(int i=1;i<=result.length;i++){
			Cell cell = row.createCell(i);
			cell.setCellValue(result[i-1]); 
		}
		try (FileOutputStream outputStream = new FileOutputStream(excelfilepath)) {
            workbook.write(outputStream);
        } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		workbook.close();*/
		SimpleDateFormat dtformat = new SimpleDateFormat("dd-MMM-yyyy HH-mm-ss");
		Date dt = new Date();
		String time = dtformat.format(dt);
		Path p = Paths.get(pdffilepath);
		String file = p.getFileName().toString();
		String[] names = {"PO Address","PO Number","PO Date","To Address","Currency","Requested By","Requested Date","Approved By","Approved Date"};
		//===================================================================
		BufferedWriter bw = new BufferedWriter(new FileWriter("D:\\Varun\\ACE\\PDFValidationDocuments\\Result\\HtmlResult\\"+DataFieldValues.getTestCaseID()+"_"+time+".html"));
		String page = "<html><body><style>body{background:#000000;font-family: Verdana, Geneva, sans-serif;text-align: center;margin:0;padding:0;}table{table-layout:fixed;background:#89B6B5;margin-left: auto;margin-right: auto;}thead{font-size:16px;background:#4D7C7B;}td{max-width:200px}th{color:#FFFF95}</style>";
		page = page+"<div align='center' style='background:#4D7C7B'><h2 style='color:#FFFF95'>DocXpress - "+DataFieldValues.getTestCaseID()+" Document Verification Results</h2>";
		page = page+"<table style='background:#4D7C7B' border='0'><colgroup><col style='width: 20%' /><col style='width: 25%' /><col style='width: 20%' /><col style='width: 35%' /></colgroup><tr style='color:#FFFF95'><td>&nbsp;Date&nbsp;&&nbsp;Time:&nbsp;</td><td>&nbsp;"+time+"</td><td>&nbsp;File&nbsp;Name:&nbsp;</td><td>&nbsp;"+file+"</td></tr></table><br></div>";
		page = page+"<br><table border='1' style='font-size:12px' width='80%' vertical-align='top' margin='1' padding='0'>";
		page = page+"<thead><th width='15%'>Entity</th><th>Input Data</th><th>PDF Content</th><th width='15%'>Comparison Result</th></thead>";
		for(int m=0;m<result.length;m++){
			if(m%2==0){
				page=page+"<tr style='font-size:14px;background:#FAFAC5;'>";
			}
			else{
				page=page+"<tr style='font-size:14px;background:#FFFF95;'>";
			}
			page = page+"<td>"+names[m]+"</td><td>"+html2[m]+"</td><td>"+html1[m]+"</td><td>"+result[m]+"</td></tr>";
		}
		page = page+"</table><br>";
		page = page+"<style>table{table-layout:fixed;border-style: solid;margin-left: auto;margin-right: auto;}td{max-width:200px}th{color:#FFAE5D}</style><table border='1' style='font-size:12px' width='100%'vertical-align='top' margin='1' padding='0'><thead><th colspan='5'>Input Data</th><th colspan='5'>PDF Content</th><tr><th width='5%'>Item No.</th><th width='6%'>Quantity</th><th>Description</th><th width='5%'>Unit price</th><th width='6%'>Amount</th><th width='5%'>Item No.</th><th width='6%'>Quantity</th><th>Description</th><th width='5%'>Unit price</th><th width='6%'>Amount</th></tr></thead>";
		for(int n=0;n<tableresults.length;n++){
			if(n%2==0){
				page=page+"<tr style='font-size:14px;background:#FAFAC5;'>";
			}
			else{
				page=page+"<tr style='font-size:14px;background:#FFFF95;'>";
			}
			page = page+"<td>"+tableresults[n][0]+"</td><td>"+tableresults[n][1]+"</td><td>"+tableresults[n][2]+"</td><td>"+tableresults[n][3]+"</td><td>"+tableresults[n][4]+"</td><td>"+tableresults[n][5]+"</td><td>"+tableresults[n][6]+"</td><td>"+tableresults[n][7]+"</td><td>"+tableresults[n][8]+"</td><td>"+tableresults[n][9]+"</td></tr>";
		}
		page = page+"</table>";
		page = page+"</body></html>";
		bw.write(page);
		bw.close();
		//===================================================================
	}
	
	public static void excelresult(String excelfilepath) throws IOException{
		FileOutputStream fileOut = new FileOutputStream(excelfilepath);
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet worksheet = workbook.createSheet("Test");	
		HSSFFont font = workbook.createFont();
		HSSFCellStyle cellStyle= workbook.createCellStyle();
		// CellStyle style = workbook.createCellStyle();
		 cellStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
	        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	        cellStyle.setBorderTop((short) 1); // single line border
	        cellStyle.setBorderBottom((short) 1); // single line border
		HSSFRow row1 = worksheet.createRow(0);
			
			Cell cellA0 = row1.createCell(0);
			cellA0.setCellValue("Form Number");
			//font.setColor(HSSFFont.);
			font.setBoldweight(Font.BOLDWEIGHT_BOLD);//Make font bold
			cellStyle.setFont(font);//set it to bold
		   // style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
		    //style.setFillPattern(CellStyle.BORDER_THICK);
			cellStyle.setAlignment(CellStyle.ALIGN_CENTER);

			cellStyle.setFont(font);
			cellA0.setCellStyle(cellStyle);
			Cell cellA1 = row1.createCell(1);
			font.setBoldweight(Font.BOLDWEIGHT_BOLD);//Make font bold
			cellStyle.setFont(font);//set it to bold
		   // cellStyle.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
		    //style.setFillPattern(CellStyle.BORDER_THICK);
		    cellStyle.setAlignment(CellStyle.ALIGN_CENTER);
			cellA1.setCellValue("HTML Result File Path");
			cellStyle.setFont(font);
			cellA1.setCellStyle(cellStyle);
			int rowcount=1;int colcount=0;
			HSSFRow row11 =worksheet.createRow(rowcount++);
			row11.createCell(colcount).setCellValue("Test3");
			Cell cellA11=row11.createCell(colcount++);
			cellA11.setCellValue("Test1");
			HSSFHyperlink sheet_link=new HSSFHyperlink(HSSFHyperlink.LINK_FILE);
			sheet_link.setAddress("test2");	
			cellA11.setHyperlink(sheet_link);
			
			workbook.write(fileOut);
			fileOut.close();
	}
}
