package ComparePDF;
import java.util.LinkedList;
import ComparePDF.diff_match_patch.Diff;
import ComparePDF.diff_match_patch.Operation;

/**
 * Using google-diff-match-patch java library to get the differences between 2 strings.
 * @author Varun
 */
public class StringDifference
{
	private int check = 0;
 
  public String[] compareStrings(String a_content,String b_content)
  {
	  String match = null;
	  diff_match_patch differ = new diff_match_patch();
	  LinkedList<Diff> deltas = differ.diff_main(a_content, b_content);
	  System.out.println(deltas);
	  differ.diff_cleanupSemantic(deltas);
	  String html1 = SideBySideDiffold(deltas);
	  String html2 = SideBySideDiffnew(deltas); 
	  if(check>0){
		  match = "UnMatched";
	  }
	  else{
		  match = "Matched";
	  }
	  String[] ret = {match,html1,html2};
	  return ret;
  }
  public String SideBySideDiffold(LinkedList<Diff> list){
		String html = "";
		for(Diff x : list){
			String data = x.text;
			Operation operation = x.operation;
			String text = (data.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>"));
			if(operation == Operation.DELETE){
				check++;
				 html = html+"<span style='color:red'><del>"+text+"</del></span>";
			 }
			 else if(operation == Operation.EQUAL){
				 html = html+"<span>"+text+"</span>"; 
			 }
		}
		System.out.println(html);
		return html;
	}
	public String SideBySideDiffnew(LinkedList<Diff> list){
		String html = "";
		for(Diff x : list){
			String data = x.text;
			Operation operation = x.operation;
			String text = (data.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>"));
			if(operation == Operation.INSERT){
				check++;
				 html = html+"<span style='color:red'><del>"+text+"</del></span>";
			 }
			 else if(operation == Operation.EQUAL){
				 html = html+"<span>"+text+"</span>"; 
			 }
		}
		System.out.println(html);
		return html;
	}
 
}