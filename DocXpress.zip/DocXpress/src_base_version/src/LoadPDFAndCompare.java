import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripper;


public class LoadPDFAndCompare {

	static PDDocument actualDocument;
	static String outPutForm = "D:\\PDFValidationDocuments\\OutPutPDF\\";
		public LoadPDFAndCompare() {
		// TODO Auto-generated constructor stub
	}
	public static void LoadPDFAndComparePDF(String actualForm, String mockUpForm, String formNumber, String formTitle, String type,String excelResultFile,String pdfResultFile, String testcaseName) throws IOException {
		try {
		List<PDPage> list = loadactualPDF(actualForm);
		if(type!="Dynamic"){
			if(formTitle=="")
				
					outPutForm = NonStackedLineByLineOutputPDF.getStartEndPageandCreateNewOutPutPDFNonStacked(actualDocument,outPutForm,list,formNumber);
				
			else
				outPutForm =StackedLineByLineOutputPDF.getStartEndPageandCreateNewOutPutPDFStacked(actualDocument,outPutForm,list,formNumber,formTitle);
			compareOutputandMock(mockUpForm,formNumber,excelResultFile,pdfResultFile);
		}
		else{
			DynamicContent.DynamicContentPDF(actualDocument,list,formNumber,formTitle,actualForm,mockUpForm,excelResultFile,testcaseName);
		}
				
	} catch (COSVisitorException | IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		finally{
			if(actualDocument!=null)
				actualDocument.close();
		}
	}	
	 
	private static void compareOutputandMock(String mockUpForm, String formNumber, String excelResultFile,String pdfResultFile) throws COSVisitorException {
		
		try {
			PDDocument mockdocument =PDDocument.load(mockUpForm);
			PDFTextStripper mocktextStripper=new PDFTextStripper();
			List<PDPage> mocklistOfPages = mockdocument.getDocumentCatalog().getAllPages();
			String mockPages = null;
			
			
			PDDocument outputdocument = PDDocument.load(outPutForm);
			PDFTextStripper outputtextStripper=new PDFTextStripper();
			List<PDPage> outputlistOfPages = outputdocument.getDocumentCatalog().getAllPages();
			String outputPages = null;
							
				mocktextStripper.setStartPage(1); 
				mocktextStripper.setEndPage(mocklistOfPages.size());
				mockPages = mocktextStripper.getText(mockdocument);	
			
				outputtextStripper.setStartPage(1); 
				outputtextStripper.setEndPage(mocklistOfPages.size());
				outputPages = outputtextStripper.getText(outputdocument);
				
				CompareLineByLineMockAndOutPut(mockPages,outputPages,formNumber,excelResultFile,pdfResultFile);
				deleteOutputPDF(outPutForm);
				
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
	private static void deleteOutputPDF(String outPutForm2) {
		File filedelete = new File(outPutForm2);		 
		filedelete.delete();

		
	}
	private static void CompareLineByLineMockAndOutPut(String mockPages,
			String outputPages, String formNumber, String excelResultFile,String pdfResultFile) throws IOException, COSVisitorException {
		String[] mocklLineSplit = null;
		String[] outputlLineSplit = null ;
		
		mocklLineSplit = mockPages.split("\r\n");
		outputlLineSplit = outputPages.split("\r\n");
		
		boolean mockLinehighest = mocklLineSplit.length > outputlLineSplit.length;
		int linelowest;
		int wordlowest;
		String Result[] = new String[4];
		
		
		if(mockLinehighest)
			linelowest = outputlLineSplit.length;
		else 
			
			linelowest = mocklLineSplit.length;
		
		for(int i=0,j=0; i< linelowest || j< linelowest ;i++,j++){
			
						
			if(mocklLineSplit[i].trim().equals(outputlLineSplit[j].trim()))
			{
				Result[0] = "pass";
				Result[1] = mocklLineSplit[i];
				Result[2] = outputlLineSplit[j];
				Result[3]= "No Error";
			}
			else{
				
				String[] mockWordsinLine = mocklLineSplit[i].split(" ");
				System.out.println("---------------------------------------");
				System.out.println("Line "+ i+ " "+mocklLineSplit[i]);
				String[] outPutWordinLine = outputlLineSplit[i].split(" ");
				System.out.println(outputlLineSplit[i]);
				boolean mockword = mockWordsinLine.length > outPutWordinLine.length;
				if(mockword)
					wordlowest = outPutWordinLine.length;
				else 
					wordlowest = mockWordsinLine.length;
				int l;	
				for(l=0;l<wordlowest;l++){
					
					if(mockWordsinLine[l].equals(outPutWordinLine[l]))
					{
						Result[0] = "pass";
					}
					else{
						Result[0] = "Fail";
						Result[1] = mocklLineSplit[i];
						Result[2] = outputlLineSplit[j];
						if(outPutWordinLine[l].equals("")){
							outPutWordinLine[l] = "<space>";
						}
						if(l>0 & l!=(wordlowest-1))
							Result[3] = outPutWordinLine[l-1] + " " + outPutWordinLine[l] +" " + outPutWordinLine[l+1];
						else if(l>0 & l==(wordlowest-1))
							Result[3] = outPutWordinLine[l-1] + " " + outPutWordinLine[l];
						else if(l==0 & (outPutWordinLine[l].length()==1))
							Result[3] = outPutWordinLine[l];
						else if(l==0 & l!=(wordlowest-1))
							Result[3] = outPutWordinLine[l];
						else
							Result[3] = outPutWordinLine[l];
						
						break;
					}
				}
				if(l==wordlowest){
					Result[0] = "Fail";
					Result[1] = mocklLineSplit[i];
					Result[2] = outputlLineSplit[j];
					if(mockword)
						Result[3]= mocklLineSplit[i].substring(outPutWordinLine.length, mockWordsinLine.length);
					else
						Result[3]= outputlLineSplit[i].substring(mockWordsinLine.length, outPutWordinLine.length);
				}
				
			}
//			int h=1;
//			if(i==(linelowest-1)){
//				h= 2;
//			}
			PDFResult.createUpdatePDF(Result,i,formNumber,pdfResultFile);
			ExcelResult.createExcel(Result,i,formNumber,excelResultFile);
			
		}		
		
	}

	
	private static List<PDPage> loadactualPDF(String actualForm) throws IOException {
		
		
			PDDocument actualDocumen = new PDDocument();
			actualDocumen = PDDocument.load(actualForm);
			actualDocument = actualDocumen;
			//PDDocument newdocument = new PDDocument();
			List<PDPage> list = actualDocument.getDocumentCatalog().getAllPages();			
			return list;
		
		
	}
	public static String GenratrateCurrentDate() {
		
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date = new Date();
		String dateTime = dateFormat.format(date);
		dateTime= dateTime.replace("/", "");
		dateTime= dateTime.replace(":", "");
		return dateTime;
	}
		
	}


