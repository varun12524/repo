import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;


public class CompareDynamicData {
	
	static FileInputStream file = null;
	static HSSFWorkbook workbook = null;
	static HSSFSheet sheet = null;
	static HashMap<String,String> dynamicValues = null;
	static String testcaseName= null;

	public CompareDynamicData(String testcaseName) {
		this.testcaseName =testcaseName;
		getValuesFromTestDataSheet();
		
	}

	private static void getValuesFromTestDataSheet() {
		
		loadTestDataSheet();
		dynamicValues = readRowColumnValues();		
	}

	private static HashMap<String, String> readRowColumnValues() {
		int rowNumber = 0;
		HSSFRow row = sheet.getRow(0);
		Iterator<Cell> cellIterator = row.cellIterator();
		dynamicValues = new HashMap<String,String>(); 
		Iterator<Row> rowIterator = sheet.iterator();
		while(rowIterator.hasNext()) {
	        Row row1 = rowIterator.next();
	        Cell cell1 = row1.getCell(0);
	        if(cell1.getStringCellValue().equals(testcaseName)){
	        	rowNumber = row1.getRowNum();
	        }
		}
	        HSSFRow testCaseRow = sheet.getRow(rowNumber);
	        Iterator<Cell> cellB1 = testCaseRow.cellIterator();
		while(cellIterator.hasNext()) {
			Cell cell = cellIterator.next();
			Cell cellB = cellB1.next();
			dynamicValues.put(cell.getStringCellValue(), cellB.getStringCellValue());
		}
		return dynamicValues;
		
	}
	

	private static void loadTestDataSheet() {
		try {
			file = new FileInputStream(new File("D:\\PDFValidationDocuments\\TestData\\TestDataForDynamicPDF.xls"));
			workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheetAt(0);			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
