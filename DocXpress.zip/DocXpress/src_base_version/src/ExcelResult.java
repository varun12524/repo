import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;


public class ExcelResult {
	
	static HSSFWorkbook workbook = null;
    static HSSFSheet worksheet = null;
    static FileOutputStream fileOut = null;
    static FileInputStream fileIn = null;
	
	public ExcelResult() {
		
	}
	
public static void createExcel(String[] result, int i, String formNumber, String excelResultFile) throws IOException{
	File file = new File(excelResultFile);    
	if (!file.exists()) {
		createDocument(formNumber,excelResultFile,"Static");
		updateDocument(result,i);
	}	
	else{
		openDocument(formNumber,excelResultFile,"Static");
		updateDocument(result,i);
	}
	//if(h==2)	
		flushall();
		
	}

static void openDocument(String formNumber, String excelResultFile, String type) throws FileNotFoundException {
	
	fileIn = new FileInputStream(excelResultFile);
	fileOut = new FileOutputStream(excelResultFile);
	//workbook = new HSSFWorkbook();
	if(workbook.getSheet(formNumber)!=null){
		worksheet = workbook.getSheet(formNumber);
	}
	else{
		worksheet = workbook.createSheet(formNumber);
		updateSheetHeader(type);
	}
	
}

private static void updateDocument(String[] result, int i) throws IOException {
	HSSFRow row1 = worksheet.createRow(i+1);
	
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Line No   "+i);
	
	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue(result[1]);
	
	Cell cellA2 = row1.createCell(2);
	cellA2.setCellValue(result[2]);
	
	Cell cellA3 = row1.createCell(3);		
	cellA3.setCellValue(result[0]);
	
	
	Cell cellA4 = row1.createCell(4);
	cellA4.setCellValue(result[3]);
	workbook.write(fileOut);
}

static void flushall() throws IOException {
	
	
	fileOut.flush();
	fileOut.close();
	if(fileIn!=null)
	fileIn.close();
	
}

static void createDocument(String formNumber, String excelResultFile, String type) throws FileNotFoundException {
	
	fileOut = new FileOutputStream(excelResultFile);
	workbook = new HSSFWorkbook();
	worksheet = workbook.createSheet(formNumber);
	updateSheetHeader(type);
	//workbook.getSheet("");
	
}

private static void updateSheetHeader(String type) {
HSSFRow row1 = worksheet.createRow(0);	
	
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Actual Line");
	
	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue("Actual Line");
	if(type=="Static"){
	Cell cellA2 = row1.createCell(2);
	cellA2.setCellValue("Mock Line");
	
	Cell cellA3 = row1.createCell(3);
	cellA3.setCellValue("Pass/Fail");
	
	Cell cellA4 = row1.createCell(4);
	cellA4.setCellValue("Error in Place");}
	else{
		
		Cell cellA2 = row1.createCell(6);
		cellA2.setCellValue("Mock Line/TestData Value");
		
		Cell cellA3 = row1.createCell(7);
		cellA3.setCellValue("Pass/Fail");
		
	}
}

static void updateDynamicDocument(ArrayList<String> resultList, int i, String mockOrTestdataValue, String passOrFail) throws IOException {
	HSSFRow row1 = null;
	//int rowNumber = 0;
//	
		for (int n = 0; n < resultList.size(); n++) {

			if (n == 0) {
				row1 = worksheet.createRow(i + 1);
			}
			//rowNumber = row1.getRowNum();
			Cell cellA5 = row1.createCell(0);
			cellA5.setCellValue("Line No   " + (i + 1));

			Cell cellA1 = row1.createCell(n + 1);
			cellA1.setCellValue(resultList.get(n));
			
		
		//row1 = worksheet.getRow(rowNumber);
		Cell cellB1 = row1.createCell(6);
		cellB1.setCellValue(mockOrTestdataValue);
		
		Cell cellB2 = row1.createCell(7);
		cellB2.setCellValue(passOrFail);
		workbook.write(fileOut);
}
	}


	}


