import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripper;


public class DynamicContent {
	
	static String ExcelResultFile= null;
	static String FormNumber = null;

	public DynamicContent() {
		// TODO Auto-generated constructor stub
	}
	
	public static void DynamicContentPDF(PDDocument actualDocument, List<PDPage> list, String formNumber, String formTitle, String actualForm, String mockUpForm, String excelResultFile, String testcaseName) throws IOException, COSVisitorException{
		
		ExcelResultFile= excelResultFile;
		FormNumber = formNumber;
		String pages = null;
		boolean found = false;
		boolean firstPage = true;
		int startPage = 0;
		int endPage = 0;
		for (int i = 1; i <= list.size(); i++) {
			PDFTextStripper textStripper = new PDFTextStripper();
			textStripper.setStartPage(i);
			textStripper.setEndPage(i);

			pages = textStripper.getText(actualDocument);
			String[] lines = pages.split("\\n");
			String line2 = lines[1];

			found = (line2.contains(formNumber) || lines[4]
					.contains(formNumber));
			if (found == true) {

				if (firstPage == true) {
					startPage = i;
					firstPage = false;
					endPage = i;
				} else {
					endPage = i;
				}
			}

		}
		actualDocument.close();
		getresult(formNumber, formTitle, actualForm, mockUpForm, startPage,
				endPage,testcaseName);
	}

	private static void getresult(String formNumber, String formTitle,
			String actualForm, String mockUpForm, int startPage, int endPage, String testcaseName)
					throws COSVisitorException {

		String[] mocklLineSplit = null;
		String[] actualLineSplit = null;

		try {

			PDDocument outputdocument = PDDocument.load(actualForm);
			PDFTextStripper outputtextStripper = new PDFTextStripper();
			String actualPages = null;

			outputtextStripper.setStartPage(startPage);
			outputtextStripper.setEndPage(endPage);
			actualPages = outputtextStripper.getText(outputdocument);
			
			PDDocument mockdocument =PDDocument.load(mockUpForm);
			PDFTextStripper mocktextStripper=new PDFTextStripper();
			String mockPages = null;
			
			mocktextStripper.setStartPage(1); 
			mocktextStripper.setEndPage(1);
			mockPages = mocktextStripper.getText(mockdocument);	

			actualLineSplit = actualPages.split("\r\n");
			mocklLineSplit = mockPages.split("\r\n");
			getValuesforExcel(actualLineSplit,testcaseName);
			//CompareDynamicData.compareDynamicValues(ExcelResultFile,FormNumber);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void getValuesforExcel(String[] actualLineSplit, String testcaseName)
			throws IOException {
		//HashMap<String,String> dynamicValues = null;
		CompareDynamicData compareDynamicData = new CompareDynamicData(testcaseName);
		String[] dynamicCompareResult = new String[2];
		int i = 0;
		int h = 1;
		while (i < actualLineSplit.length) {
			ArrayList<String> resultList = new ArrayList<String>();
			if (actualLineSplit[i].contains("POLICY INFORMATION:")) {
				resultList.add(actualLineSplit[i]);
				DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber," "," ");
				i++;
				for (int j = i; j < actualLineSplit.length; j++) {
					resultList = new ArrayList<String>();
					if (actualLineSplit[j].contains("DRIVERS ON YOUR POLICY:")) {
						// i++;
						break;
					}
					String[] splitValues = actualLineSplit[j].split(":", 2);
					for (String splitValue : splitValues) {
						resultList.add(splitValue);						
					}
					dynamicCompareResult[0] = compareDynamicData.dynamicValues.get(splitValues[0]);
					if(splitValues[1].equals(dynamicCompareResult[0])){
						dynamicCompareResult[1] = "Pass";
						System.out.println("pass for policy");
					}
					else{
						dynamicCompareResult[1] = "Fail";}
					DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber,dynamicCompareResult[0],dynamicCompareResult[1]);
					i++;
				}

			} else if (actualLineSplit[i].contains("DRIVERS ON YOUR POLICY:")) {
				resultList.add(actualLineSplit[i]);
				DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber," "," ");
				i++;
				for (int j = i; j < actualLineSplit.length; j++) {
					if (actualLineSplit[j].contains("VEHICLES COVERED:")) {
						break;
					}
					resultList = new ArrayList<String>();
					String[] splitValues = actualLineSplit[j].split(" ", 2);
					for (String splitValue : splitValues) {
						resultList.add(splitValue);
					}
					String combinedresult = convertarrayListToString(resultList);
					dynamicCompareResult[0] = compareDynamicData.dynamicValues.get("DRIVERS ON YOUR POLICY:");
					if(combinedresult.equals(dynamicCompareResult[0])){
						dynamicCompareResult[1] = "Pass";
						System.out.println("pass for DRIVERS ON YOUR POLICY:");
					}
					else{
						dynamicCompareResult[1] = "Fail";}
					DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber,dynamicCompareResult[0],dynamicCompareResult[1]);
					i++;

				}
			} else if (actualLineSplit[i].contains("Vehicle:")) {
				resultList = new ArrayList<String>();
				String[] splitValues = actualLineSplit[i].split(":");
				resultList.add(splitValues[0]);
				resultList.add(splitValues[1]);
				resultList.add(splitValues[2]);
				DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber," "," ");
				i++;
				int r =1;
				for (int j = i; j < actualLineSplit.length; j++) {
					if (actualLineSplit[j]
							.contains("Total Premium All Vehicles:")) {
						break;
					}
					resultList = new ArrayList<String>();					
					splitValues = actualLineSplit[j].split(" ");
					resultList.add(Arrays.toString(Arrays.copyOfRange(
							splitValues, 0, splitValues.length - 2)));
					resultList.add(splitValues[splitValues.length - 2]);
					resultList.add(splitValues[splitValues.length - 1]);
					String combinedresult = convertarrayListToString(resultList);
					dynamicCompareResult[0] = compareDynamicData.dynamicValues.get(("Vehicle"+r));
					System.out.println("e  "+dynamicCompareResult[0]);
					if(combinedresult.equals(dynamicCompareResult[0])){
						dynamicCompareResult[1] = "Pass";
						System.out.println("pass for vehicle");
					}
					else{
						dynamicCompareResult[1] = "Fail";}
					r++;
					DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber,dynamicCompareResult[0],dynamicCompareResult[1]);
					i++;
				}
			} else if (actualLineSplit[i]
					.contains("Total Premium All Vehicles:")) {
				for (int j = i; j < actualLineSplit.length; j++) {
					if (actualLineSplit[j].equals(" ")) {
						break;
					}
					resultList = new ArrayList<String>();
					String[] splitValues = actualLineSplit[j].split(":", 2);
					for (String splitValue : splitValues) {
						resultList.add(splitValue);
					}
					DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber," "," ");
					i++;

				}
			} else {
				resultList.add(actualLineSplit[i]);

				DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber," "," ");
				i++;
			}

			if (i == actualLineSplit.length) {
				h = 2;
			DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber," "," ");
			}
		}

	}

	private static String convertarrayListToString(ArrayList<String> resultList) {
		
		String listString = "";
		for (String s : resultList)
		{
		    listString += s + ";";
		}
		System.out.println("a  "+listString.substring(0,listString.length()-1));
		return listString.substring(0,listString.length()-1);
	}	
		
	}


