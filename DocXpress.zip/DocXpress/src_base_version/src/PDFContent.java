import java.io.IOException;

import org.apache.pdfbox.exceptions.COSVisitorException;


public class PDFContent {
	
	static String ExcelResultFile = "D:\\PDFValidationDocuments\\Result\\ExcelResult\\FinalResult "+LoadPDFAndCompare.GenratrateCurrentDate()+".xls";
	static String pdfResultFile = "D:\\PDFValidationDocuments\\Result\\PDFResult\\FinalResult "+LoadPDFAndCompare.GenratrateCurrentDate()+".pdf";
	static String actualForm;
	static String[] mockUpForm;
	static String[] formNumber;
	static String[] formTitle;
	static String[] type;
	static String testcaseName;
	
	public static void main(String[] args) throws COSVisitorException, IOException {
		 actualForm = //args[0];
				 "D:\\PDFValidationDocuments\\ActualPDF\\Test.pdf"; //actual PDF
		 testcaseName= //args[1];
				 "TC2";
		 mockUpForm= //args[1];
				// "D:\\PDFValidationDocuments\\CPT Samples\\Mock.pdf";//Non stacked PDF Mock
		 		   //"D:\\PDFValidationDocuments\\CPT Samples\\A-5420-1 stack mock up Created.pdf";//stacked PDF Mock
				// new String[]{"D:\\PDFValidationDocuments\\CPT Samples\\Mock.pdf","D:\\PDFValidationDocuments\\CPT Samples\\A-5420-1 stack mock up Created.pdf","D:\\PDFValidationDocuments\\CPT Samples\\Dec page mock up.pdf"};
				 new String[]{"D:\\PDFValidationDocuments\\CPT Samples\\Test.pdf"};
		 formNumber = //args[2];
				//"A-5317-4"; // Non stacked form Number
				 //"A-5420-1"; // stacked form Number
			// new String[]{"A-5317-4","A-5420-1","A-9800-0"};
				 new String[]{"322561"}; 
		 formTitle = //args[3];
				 //"Optional Limits Transportation Expenses Coverage";
				// "";
				// new String[]{"","Optional Limits Transportation Expenses Coverage",""};
				 new String[]{""};
		 type= //"NonStacked";
				// "Stacked";	 
		 		//Dynamic;
		// new String[]{"NonStacked","Stacked","Dynamic"};
				 new String[]{"NonStacked"};
		 for(int q=0;q<formNumber.length;q++)
		LoadPDFAndCompare.LoadPDFAndComparePDF(actualForm,mockUpForm[q],formNumber[q],formTitle[q],type[q],ExcelResultFile,pdfResultFile,testcaseName);
		

	}

}
