package Compas_SingleApproach;
import java.awt.Rectangle;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;


public class SingleApproach {
	static int act_from_page,act_to_page,mck_from_page,mck_to_page;
	static ArrayList<String> stat_val;
	static ArrayList<String> Mock_val;
	static String inputFile= "C:\\PDFValidationDocuments\\Runmanager.xls";
	static String act_content="",mock_content="",temp_act_content="",temp_mck_content="",mck_content="";
	static HashMap<String,String> Excelresult = null;
	static HSSFWorkbook inputworkbook = null;
	static String section1="",section2="";
    static HSSFSheet inputworksheet = null;    
    static FileInputStream inputfileIn = null;  
	static String testcaseName;
	static HSSFWorkbook workbook = null;
    static HSSFSheet worksheet = null;
    static FileOutputStream fileOut = null;
    static FileInputStream fileIn = null;
	static String formNumber_seq;
	static String Form_name="";
	static int [] actFormPages = new int[2];
	static int [] mockFormPages = new int[2];
	static int startPage=-1,endPage=-1,startpagemoc=-1,endPagemoc=-1;
	static String outPutForm="";
	static String originalForm="";
	String FormType="";
	public static void main( String[] args ) throws Exception
	{		
		PDDocument actualDocument =null;
		PDDocument mockDocument =null;
		//
		// TODO Auto-generated method stub
//public static void Spl_linesplit( PDDocument actualdocument,int startPage2,int endPage2, String Start_Text,String End_Text,String Actual_Value,int i) throws IOException
		String[] mocklLineSplit = null;
		String[] actualLineSplit = null;
		
		 LinkedHashSet <String> form_num = new LinkedHashSet<>();
		File inputfiles = new File(inputFile); 		
		inputfileIn = new FileInputStream(inputfiles);
		inputworkbook = new HSSFWorkbook(inputfileIn);
		inputworksheet = inputworkbook.getSheetAt(0);
		Iterator<Row> rowIterator = inputworksheet.iterator();
		String arr[]=null;
		String PreviousTestcaseName="";	
		String FormType="stacked";
		boolean firstTime = true; 
		int row_pointer=0;
	/*	while(rowIterator.hasNext())
		{
		
			Row row1 = rowIterator.next();
			Cell cell0 = row1.getCell(0);
			testcaseName = cell0.getStringCellValue();			
				        
				        Cell cell01 = row1.getCell(2);
				        String ExecutionFlag = cell01.getStringCellValue();
				        Cell cell1 = row1.getCell(1);
				        formNumber_seq = cell1.getStringCellValue();
				         arr=formNumber_seq.split(",");
				         System.out.println(arr[0]+"!!!!!!!!!!!!!!!!!!!!!!!!!!");
				        
		
		
		}*/
		////////////////////////////////////////******************************////////////////////////////////
	
	 File newfile=null;
	 //FileOutputStream out =new FileOutputStream(new File ("C:\\PDFValidationDocuments\\Form_Details.xls"));
		 
				//String outPutForm ="C:\\PDFValidationDocuments\\Actual_File\\46WEAAA0A6A.pdf";
	 String filepath="C:/PDFValidationDocuments/Actual_File";
	 File [] filenew= (new File(filepath)).listFiles();
	 Set<String> s = new HashSet<>();
	 for(int k=0;k<filenew.length;k++)
	 {
						 
		  outPutForm=filenew[k].getPath();		
		 System.out.println(outPutForm);
				 File actpath= new File(outPutForm);
				 originalForm=filenew[k].getName().replaceAll(".pdf", "");
				 
				  actualDocument = new PDDocument();
				  mockDocument= new PDDocument();
					try {
						
						actualDocument = PDDocument.load(outPutForm);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					PDFTextStripperByArea stripper = new PDFTextStripperByArea();
					List allPages = actualDocument.getDocumentCatalog().getAllPages();
					//System.out.println(allPages.size()+"$$$$$$$$$$$$$$$$$$");
					for(int i=0;i<allPages.size();i++)
					{
						PDPage firstPage = (PDPage)allPages.get( i );				
						stripper.extractRegions( firstPage );
						//Add Regions and Extract the contents from the Region/*
						PDRectangle pageSize = firstPage.findMediaBox();
						float ht=pageSize.getHeight();
						float wd=pageSize.getWidth();
						//System.out.println( "Page Width:" + wd );
						//System.out.println( "Page Height:" + ht );
						int x1,y1,x2,y2;
						x1=1;
						y1=(int) ht-60;
						x2=(int) (wd);
						y2=60;
						Rectangle footer = new Rectangle(x1, y1,(int) (x2), y2);
						stripper.addRegion( "footer", footer);
						stripper.extractRegions( firstPage );	
						String footer_text=stripper.getTextForRegion( "footer" );
						System.out.println(footer_text+"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
						if (footer_text.trim().length() >0){
							if(footer_text.trim().contains("WC 00 66")){
								Form_name="";
								form_num.add(Form_name.trim());
							}
							if(footer_text.contains("Printed")){
								if(Form_name.contains("Form")){					
					 Form_name=(footer_text.substring(footer_text.lastIndexOf("Form")+0,footer_text.indexOf("Printed")));
								}
								else{
									 Form_name=(footer_text.substring(0,footer_text.indexOf("Printed")));

								}
								//Form_name=(footer_text.substring(0,footer_text.indexOf("Printed")));
					  
					  if(Form_name.contains("Page")){
						  Form_name=(Form_name.substring(0,Form_name.indexOf("Page")));
						  //Form_name=Form_name.replaceAll(" ", "");
								System.out.println(Form_name+"11111111111111111111111111111");
								form_num.add(Form_name.trim());
								}
					  else
					  {
						  form_num.add(Form_name.trim());
					  }
					  
					  //Form_name=Form_name.replaceAll(" ", "");
							//System.out.println(Form_name+"11111111111111111111111111111");
							//form_num.add(Form_name.replaceAll("\\(", ""));
					 
							}
							else if(footer_text.contains("Page")){
								  Form_name=(footer_text.substring(footer_text.lastIndexOf("Form")+0,footer_text.indexOf("Page")));
								  //Form_name=Form_name.replaceAll(" ", "");
										//System.out.println(Form_name+"11111111111111111111111111111");
										form_num.add(Form_name.trim());
										}
							else if(footer_text.contains("Form")){
								System.out.println(footer_text.lastIndexOf("Form")+0);
								try
								{
									if(footer_text.contains("Signature")){
										Form_name=footer_text.substring(0,footer_text.lastIndexOf("Signature")-1);
									}else
								  Form_name=(footer_text.substring(footer_text.lastIndexOf("Form")+0,35));
								  System.out.println(Form_name + "GGGGGGGGGGGGGGGGGGGGGGGGGGG");
								}
								catch(StringIndexOutOfBoundsException e){
									Form_name=(footer_text.substring(footer_text.lastIndexOf("Form")));
									 System.out.println(Form_name + "VVVVVVVVVVVVVVVVVVVVVVVV");
								}
								  //Form_name=Form_name.replaceAll(" ", "");
	//							 System.out.println(Form_name+"$$$$$$$$$$$$$$$$$$$$$$$$");
								 //form_num.add(Form_name.replaceAll("\\(", ""));						
								form_num.add(Form_name.trim());
							}	
							else if(footer_text.contains("ACORD")){
								  Form_name=(footer_text.substring(0,footer_text.lastIndexOf(")")+1)).replaceAll("/", "");
								  //Form_name=Form_name.replaceAll(" ", "");
										//System.out.println(Form_name+"11111111111111111111111111111");
										form_num.add(Form_name.trim());
										}
							else if(footer_text.contains("\n")){
								  Form_name=(footer_text.substring(0,footer_text.indexOf("\n")+0));
								  //Form_name=Form_name.replaceAll(" ", "");
										System.out.println(Form_name+"sssssssssssssssssssssssss");
										form_num.add(Form_name.trim());
										}
							else
							{
								System.out.println(Form_name+"dsfsdss");

								form_num.add(footer_text.trim());
							}
						}
													
						//mockFormPages = GetFormpages(actualDocument, formnumber);
						//actFormPages = GetFormpages(mockDocument, formnumber);
						
						//System.out.println(mockFormPages);
						//System.out.println(actFormPages);
					}										
					Excelresult= new HashMap<String,String>();
					
					for (String ls_form:form_num)
					{
						
						System.out.println(ls_form+ "*******************************");
					String formname=ls_form.replace("/.", "_").replaceAll("//", "_");
						String mockpath="C:\\PDFValidationDocuments\\mock_File";
						newfile =new File(mockpath+"\\"+formname.trim()+".pdf");
						try {
							mockDocument = PDDocument.load(newfile);
							
							Comparepdf(mockDocument,actualDocument,FormType,ls_form,actpath.getName());
						} catch (IOException e1) {
							Excelresult.put(ls_form, "Form number format issue / Mock file Not avaialable");
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					
					}
					
					form_num.clear();
	 
	 fileOut = new FileOutputStream("C:\\PDFValidationDocuments\\Result\\ExcelResult\\"+originalForm+".xls");
		workbook = new HSSFWorkbook();
		worksheet = workbook.createSheet(originalForm);	
		HSSFFont font = workbook.createFont();
		HSSFCellStyle cellStyle= workbook.createCellStyle();
		// CellStyle style = workbook.createCellStyle();
		 cellStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
	        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	        cellStyle.setBorderTop((short) 1); // single line border
	        cellStyle.setBorderBottom((short) 1); // single line border
		HSSFRow row1 = worksheet.createRow(0);
			
			Cell cellA0 = row1.createCell(0);
			cellA0.setCellValue("Form Number");
			//font.setColor(HSSFFont.);
			font.setBoldweight(Font.BOLDWEIGHT_BOLD);//Make font bold
			cellStyle.setFont(font);//set it to bold
		   // style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
		    //style.setFillPattern(CellStyle.BORDER_THICK);
			cellStyle.setAlignment(CellStyle.ALIGN_CENTER);

			cellStyle.setFont(font);
			cellA0.setCellStyle(cellStyle);
			Cell cellA1 = row1.createCell(1);
			font.setBoldweight(Font.BOLDWEIGHT_BOLD);//Make font bold
			cellStyle.setFont(font);//set it to bold
		   // cellStyle.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
		    //style.setFillPattern(CellStyle.BORDER_THICK);
		    cellStyle.setAlignment(CellStyle.ALIGN_CENTER);
			cellA1.setCellValue("HTML Result File Path");
			cellStyle.setFont(font);
			cellA1.setCellStyle(cellStyle);
			int rowcount=1;int colcount=0;
			for (String str:Excelresult.keySet())
			{
				HSSFRow row11 =worksheet.createRow(rowcount++);
			colcount=0;
			row11.createCell(colcount++).setCellValue(str);
			
			Cell cellA11=row11.createCell(colcount++);
			cellA11.setCellValue(Excelresult.get(str));
			HSSFHyperlink sheet_link=new HSSFHyperlink(HSSFHyperlink.LINK_FILE);
			sheet_link.setAddress(Excelresult.get(str));	
			cellA11.setHyperlink(sheet_link);
			}
			workbook.write(fileOut);
			fileOut.close();
	 }
	}
		
		public static List Comparedyanamic_value(String Dynamictext,String PDFname)		
		{
			String excel="C:\\Users\\COG12768\\Desktop\\DT_PC.xls";
			File inputexcel = new File(excel); 		
			FileInputStream inputexcelfile;
			String ss="Fail";
			List Dynamiclist=new ArrayList<>();
					
			try {
				inputexcelfile = new FileInputStream(inputexcel);
				inputworkbook = new HSSFWorkbook(inputexcelfile);
				inputworksheet = inputworkbook.getSheet("PublishingOutput");	
				Iterator<Row> rowIterator = inputworksheet.iterator();
				String Exceltext="";
				
				while(rowIterator.hasNext())
				{
				
					Row row1 = rowIterator.next();
					Row row2=inputworksheet.getRow(0);
					Cell cell0 = row1.getCell(4);
				String 	Formnumber = cell0.getStringCellValue();
				//System.out.println(Formnumber+"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
					if (Formnumber.equalsIgnoreCase(PDFname.replaceAll(".pdf", "")))
							{
						//System.out.println(Formnumber+"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
						 Iterator<Cell> cellIteratordata = row1.cellIterator();
						  while(cellIteratordata.hasNext()) {
                              
                              Cell cell1 = cellIteratordata.next();
                                    
                                          
                                  if (cell1 == null)
                            	  {
                            	     System.out.println("Cell is Empty in Column:" +Exceltext);
                            	     
                            	  } else if (cell1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                            	  {
                            	     //code
                            		  //System.out.println(cell1.getStringCellValue()+"#################");
                            		  Exceltext=cell1.getStringCellValue();
                            		  if (Exceltext.replaceAll(" ", "").contains(Dynamictext.replaceAll(" ", "")) || Dynamictext.replaceAll(" ", "").contains(Exceltext.replaceAll(" ", "")))
                            		  {
                            			  ss="Pass" ;
                            			  Dynamiclist.add(ss);
                            			  Dynamiclist.add(row2.getCell(cell1.getColumnIndex())+" - "+Exceltext);
                            			  Dynamiclist.add(Dynamictext);
                            			//System.out.println(row2.getCell(cell1.getColumnIndex())+"111");
                            			  break;
                            		  }
                            				  
                            	  } 
                            	  else if (cell1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                            	  {
                            	                                		  
                            		  if (HSSFDateUtil.isCellDateFormatted(cell1)) { 
                            		 // System.out.println(new SimpleDateFormat("MM/dd/YY").format(cell1.getDateCellValue())+"######################");
                            		  Exceltext=new SimpleDateFormat("MM/dd/YY").format(cell1.getDateCellValue());
                            		  if (Exceltext.replaceAll(" ", "").contains(Dynamictext.replaceAll(" ", "")) || Dynamictext.replaceAll(" ", "").contains(Exceltext.replaceAll(" ", "")))
                            		  {
                            			  ss="Pass" ;
                            			  Dynamiclist.add(ss);
                            			  Dynamiclist.add(row2.getCell(cell1.getColumnIndex())+" - "+Exceltext);
                            			  Dynamiclist.add(Dynamictext);
                            			 // System.out.println(row2.getCell(cell1.getColumnIndex())+"111");
                            			  break;
                            		  }
                            			
                            		  }
                            		  else{
                            			  //System.out.println(cell1.getNumericCellValue()+"#################"); 
                            			  Exceltext=cell1.getNumericCellValue()+"";
                                		  if (Exceltext.replaceAll(" ", "").contains(Dynamictext.replaceAll(" ", "")) || Dynamictext.replaceAll(" ", "").contains(Exceltext.replaceAll(" ", "")))
                                		  {
                                			  ss="Pass" ;
                                			  Dynamiclist.add(ss);
                                			  Dynamiclist.add(row2.getCell(cell1.getColumnIndex())+" - "+Exceltext);
                                			  Dynamiclist.add(Dynamictext);
                                			 // System.out.println(row2.getCell(cell1.getColumnIndex())+"111");
                                			  break;
                                		  }
                            		  }
                            	  } 
                            	 
						      
				
			} 
						  										
														
							}}
				
			
			
			if (ss.equals("Fail")){
				 Dynamiclist.add(ss);
   			  Dynamiclist.add("");
   			  Dynamiclist.add(Dynamictext);
			}
			}catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return Dynamiclist;
			
		}
//While loop closing	 
	public static void Comparepdf(PDDocument mockDocument,PDDocument actualDocument,String FormType,String ls_form,String PDFname)
	{
		mockFormPages = GetFormpages(mockDocument, ls_form);
		actFormPages = GetFormpages(actualDocument, ls_form);
		startPage=actFormPages[0];
        endPage=actFormPages[1];
        startpagemoc=mockFormPages[0];
        endPagemoc=mockFormPages[1];
        FormType="";
        String formexcel="C:\\PDFValidationDocuments\\Form_Details.xls";
		File inputexcel = new File(formexcel); 	
		FileInputStream inputexcelfile;
        try {
        	inputexcelfile = new FileInputStream(inputexcel);
			inputworkbook = new HSSFWorkbook(inputexcelfile);
			inputworksheet = inputworkbook.getSheetAt(0);	
			Iterator<Row> rowIterator = inputworksheet.iterator();
			while(rowIterator.hasNext())
			{
			
				Row row1 = rowIterator.next();
				if (row1.getCell(0).getStringCellValue().equalsIgnoreCase(ls_form))
				{
					FormType=row1.getCell(1).getStringCellValue();
					break;
				}
			}
			 String actualPages = null;
		        String mockpages=null;
			if (!FormType.equalsIgnoreCase("Columnar"))
			{
        PDFTextStripper actualtextStripper = new PDFTextStripper();
        PDFTextStripper mocktextStripper = new PDFTextStripper();
       
        actualtextStripper.setStartPage(startPage+1);
        actualtextStripper.setEndPage(endPage+1);
        				mockpages = mocktextStripper.getText(mockDocument);
        				// Spliting the File text
        				String [] Mocksplit= mockpages.replaceAll("\r\n", " ").split(" ");
        				//String Mocksplit= mockpages.replaceAll("\r\n", "").replaceAll(" ", "");
        				//System.out.println("#################################"+Arrays.toString(Mocksplit)+"#################");
                        actualPages = actualtextStripper.getText(actualDocument);
                       String [] Actsplit= actualPages.replaceAll("\r\n", " ").split("");
                       // System.out.println("#################################"+Arrays.toString(Actsplit)+"#################");
                        int [] a=new int [5];
			}
			else
			{
				 stat_val= staticcolumnar("actual",actualDocument,ls_form);
			      System.out.println(stat_val.get(0));
			      
			       
			       Mock_val= staticcolumnar("Mock",mockDocument,ls_form);
			       System.out.println(Mock_val.get(0));
			       act_content="";
			       mock_content=""; 
			       for(int i=0;i<stat_val.size();i++)
			       {
			    		act_content+=stat_val.get(i);
			    		//mock_content+=Mock_val.get(i);
			       }
			       for(int i=0;i<Mock_val.size();i++)
			       {
			    		//act_content+=stat_val.get(i);
			    		mock_content+=Mock_val.get(i);
			       }
			       actualPages=act_content;
			       mockpages=mock_content;
			       act_content="";
			       mock_content=""; stat_val.clear();Mock_val.clear();
			     
			}
                    //  ComparebyDefault(actualPages.replaceAll("\r\n","").replaceAll(" ", ""),mockpages.replaceAll("\r\n", "").replaceAll(" ", ""),"All",1,PDFname,ls_form);
                      
			 ComparebyDefault(actualPages.replaceAll("\r\n"," "),mockpages.replaceAll("\r\n", " "),"All",1,PDFname,ls_form);
			// int j=0;
                        // Reading 
                        /*for (int i=0;i<Actsplit.length;i++)
                        {
                        	
                        if(!((Actsplit[i].replaceAll(" ", "")).equals((Mocksplit[j].replaceAll(" ", "")))))
                        {
                        	if (Actsplit[i].equals(" ") || Actsplit[i].equals("") )
                        	{
                        		j--;
                        		
                        	}
                        else if(Mocksplit[j].equals(" ") || Mocksplit[j].equals(""))
                        {
                        	i--;
                        }
                        else
                        {
                        	System.out.println(Actsplit[i]+"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"+ Mocksplit[j]);
                        	break;
                        }
                        	
                        }
                        j++;
                        }
                        */
                        
        } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
        }
	}
	
	public static int[] GetFormpages(PDDocument document, String form_number)
	{
		int from_page=-1, to_page=-1,first_time=0;
		int[] page_return=new int[2];
		//System.out.println(form_number);
		try
		{
			PDFTextStripperByArea stripper = new PDFTextStripperByArea();
			stripper.setSortByPosition( true );
			List allPages = document.getDocumentCatalog().getAllPages();
			System.out.println(allPages.size()+"AAAAAAAAAAAAAAAAAAAAAAAAA");
			for(int i=0;i<allPages.size();i++)
			{
				PDPage firstPage = (PDPage)allPages.get( i );				
				stripper.extractRegions( firstPage );
				//Add Regions and Extract the contents from the Region/*
				PDRectangle pageSize = firstPage.findMediaBox();
				float ht=pageSize.getHeight();
				float wd=pageSize.getWidth();
				//System.out.println( "Page Width:" + wd );
				//System.out.println( "Page Height:" + ht );
				int x1,y1,x2,y2;
				x1=1;
				y1=(int) ht-70;
				x2=(int) (wd);
				y2=60;
				Rectangle footer = new Rectangle(x1, y1,(int) (x2/2), y2);
				stripper.addRegion( "footer", footer);
				stripper.extractRegions( firstPage );	
				String footer_text=stripper.getTextForRegion( "footer" );
				if(footer_text.trim().contains(form_number.trim()))
				{
					if(first_time==0)
					{
						from_page=i;
						first_time=1;
					}
					else
					{
						to_page=i;
					}
				}				
			}
			if(from_page>-1 && to_page==-1)
			{
				to_page=from_page;				
			}
			page_return[0]=from_page;
			page_return[1]=to_page;
			System.out.println(form_number);
			//System.out.println(from_page + to_page+ "!!!!!!!!!!!");
			
			return page_return;
			
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			
		}
		return page_return;
	}
	
	public static void ComparebyDefault(String a_content,String b_content, String section,int result_row,String PDFname,String ls_form)
	{
		   try
		   {
			System.out.println("Actual Content:"+ a_content);
			b_content=b_content.replaceAll("ABCDEFGHIJ", "");
			System.out.println("Mock Content:"+ b_content);
			diff_match_patch d=new diff_match_patch();
			LinkedList diff=d.diff_main(b_content, a_content);
			section1=section;
			mck_content=b_content;
			act_content=a_content;
			String ss=d.diff_prettyHtml(diff,PDFname);
			int rr=d.diff_levenshtein(diff);
			String Result[] = new String[4];
			if(rr==0){				
				System.out.println("No Error Found:" + ss);				
				Result[0] = "Pass";	
				}
			else{
				System.out.println("Error Found:" + ss); 				
				Result[0] = "Fail";	
			}		
			Result[1] =mck_content;
			Result[2] =act_content;
			//Result[3]= "C:\\PDFValidationDocuments\\Result\\HtmlResult\\"+ls_form+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".html";
			Result[3]= "C:\\PDFValidationDocuments\\Result\\HtmlResult\\"+ls_form+"_"+originalForm+".html";
			Excelresult.put(ls_form, Result[3]);
			CreateHtml(ss,Result[3]);
			/*if (section1.contains("static")){
				ExcelResult.createExcel(Result,result_row,PDFContent.formNumber+"_"+section1,PDFContent.ExcelResultFile);
			}
			else{
			ExcelResult.createExcel(Result,result_row,PDFContent.formNumber+"_"+PDFContent.compare_type,PDFContent.ExcelResultFile);
			}*/
			//PDFResult.createUpdatePDF(Result,j,PDFContent.formNumber,PDFContent.pdfResultFile);
			//CompareWordByWordIfLineFails.compareWordByWord(mck_content,act_content);
		   }
		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
	}
	
	public static void CreateHtml(String s,String section){
		

	    try {
	    	PrintStream out = new PrintStream(new FileOutputStream(section));
	    	byte[] bb=s.getBytes();
	    	
	    	out.write(bb);
	    	
	    	
	    		
	    } 
	catch (IOException x) {
	      System.out.println("Exception thrown: " + x);
	    }

	}

	public static ArrayList staticcolumnar(String act_mock,PDDocument document,String formNumber)

	{	
				
		int[] page_return=new int[2];
		int from_page,to_page;
		int start_page_no;
		
		page_return=GetFormpages(document,formNumber);
		from_page=page_return[0];
		to_page=page_return[1];
		
		String Total_Text="";
		ArrayList<String> List1 = new ArrayList<>();
		
		/*if(act_mock=="actual")
		{
			from_page=act_from_page;
			//from_page=0;
			to_page=act_to_page;	
			//to_page=0;
			
		}
		else
		{
			from_page=mck_from_page;
			to_page=mck_to_page;
			//from_page=0;
			//to_page=0;
		}*/
		
		try
		{			
			
			List allPages = document.getDocumentCatalog().getAllPages();
		System.out.println(from_page+"AAAAAAAAAAAAAAAAAAAAAAAAAA" +to_page +"AAA"+allPages.size());
			start_page_no=-1;
				for(int i=from_page;i<=to_page;i++)
				{
					PDPage firstPage = (PDPage)allPages.get( i );
					PDFTextStripperByArea stripper = new PDFTextStripperByArea();
					stripper.setSortByPosition( true );
					stripper.extractRegions( firstPage );
					//Add Regions and Extract the contents from the Region/*
					PDRectangle pageSize = firstPage.findMediaBox();
					float ht=pageSize.getHeight();
					float wd=pageSize.getWidth();
					System.out.println( "Page Width:" + wd );
					System.out.println( "Page Height:" + ht );
					int x1,y1,x2,y2;
					//Find the starting point and ending point of the section
					x1=1;
					y1=1;
					x2=(int) (wd);
					y2=(int) (ht);
					int counter=1;					
					int no_of_lines=0;
										
					
						Rectangle r1 = new Rectangle(x1, (y1), (x2/2), y2);
						stripper.addRegion( "R"+counter, r1 );
						stripper.extractRegions( firstPage );
						String left =stripper.getTextForRegion( "R"+counter );
						
						PDFTextStripperByArea stripper2 = new PDFTextStripperByArea();
						stripper2.setSortByPosition( true );	
						Rectangle right = new Rectangle((int) (x2/2),(y1),x2,y2);
						
						stripper2.addRegion( "right"+counter, right);
						stripper2.extractRegions( firstPage );	
						String Right=stripper2.getTextForRegion( "right"+counter );
						//System.out.println("Bottom_Left:" +right);
					 Total_Text=left+Right;
					 System.out.println(Total_Text);
					 List1.add(Total_Text);	
				


	}}
	catch(Exception e)
	{e.printStackTrace();
		}
		return List1;
	}

}
